export const jwtConstants = {
    secret: 'arnabishakh', 
  };
  